package com.example.fire

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity

class FirefighterDashboardActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_firefighter_dashboard)
    }
}

