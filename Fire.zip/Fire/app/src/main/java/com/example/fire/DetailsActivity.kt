package com.example.fire

class DetailsActivity {
}